const Error = () => {  
    return <>
      <div  className="errorpage d-flex flex-wrap justify-content-center align-items-center" >
         <div className=" text-center">
             <h1>404</h1>
             <p>Page Not Found !!</p>
         </div>
      </div> 
    </>   
}

export default Error; 